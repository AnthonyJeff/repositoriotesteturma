<form action="#" method="POST">
	<input type="number" name="n1" placeholder="N1"><br>		
	<select name="OP">
		<option>+</option>
		<option>-</option>
		<option>*</option>
		<option>/</option>
	</select><br>		
	<input type="number" name="n2" placeholder="N2"><br>		
	<input type="submit" name="submit" value="CALCULAR">
</form>

<?php 
	
	if(isset($_POST['submit'])){
		switch ($_POST['OP']) {
			case '+':
				echo ($_POST['n1'] + $_POST['n2']);
				break;

			case '-':
				echo ($_POST['n1'] - $_POST['n2']);
				break;

			case 'x':
				echo ($_POST['n1'] * $_POST['n2']);
				break;

			case '/':
				echo ($_POST['n1'] / $_POST['n2']);
				break;
			default:
				# code...
				break;
		}	
		
	}
?>