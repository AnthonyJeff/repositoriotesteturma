<!--  
	01 -  Crie um programa que leia 10 números e informe a média aritmética e a soma dos números. O uso de formulários nessa questão lhe dará o bônus de 2 escores. (2 esc)
-->
<?php 
	

  //declaração de variáveis
  $valor1 = $_GET['v1'];
  $valor2 = $_GET['v2'];
  $valor3 = $_GET['v3'];
  $valor4 = $_GET['v4'];
  $valor5 = $_GET['v5'];
  $valor6 = $_GET['v6'];
  $valor7 = $_GET['v7'];
  $valor8 = $_GET['v8'];
  $valor9 = $_GET['v9'];
  $valor10 = $_GET['v10'];

  //soma os valores e divide por 10
  $media = ($valor1 + $valor2 + $valor3 + $valor4 + $valor5 + $valor6 + $valor7 + $valor8 + $valor9 + $valor10)/10;	
  echo array_sum($_GET)."<br>"; 
  echo $media;

/*
<form action="#" method="POST">
	<?php for($campos = 1;$campos<11;$campos++): ?>
		<input type="text" name="numero_<?=$campos;?>" placeholder="Numero <?=$campos;?>" value="<?=rand(0,1000);?>"><br>
	<?php endfor; ?>
	<input type="submit" name="submit">
</form>

<?php  
	if(isset($_POST['submit'])){
		unset($_POST['submit']);//Removendo um elemento do array
		echo "A soma é: ".array_sum($_POST)."<br>";
		echo "A média é: ".array_sum($_POST)/count($_POST)."<br>";
	}

?>