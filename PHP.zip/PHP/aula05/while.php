<?php  

	# Enquanto a minha condição for verdade, faça isso
	# Contador de 0 a 10
	
	$m = 0;
	while ($m < 11){
		echo "Contando (M) ... $m <br>";
		$m++;
	}
	echo "<hr>";
	
	$k = 0;
	for(;$k<11;){
		echo "Contando (K)... $k <br>";
		$k++;
	}
	echo "<hr>";
	
	$n = 12;
	do {
		echo "Contando (N) ... $n <br>";
		$n++;	
	} while ($n < 11);




?>