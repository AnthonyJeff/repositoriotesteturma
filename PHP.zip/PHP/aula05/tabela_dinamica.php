<?php  
	
	$linhas = 5;
	$colunas = 5;

	//phpinfo();
?>
<!DOCTYPE html>
<html>
<head>
	<title> Tabela  </title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
</head>
<body>
	<div class="container-fluid">
	  <div class="row">
		<div class="col-1"></div>			    
		<div class="col-10">
			<h1 class="text-center"> Listagem de Dados </h1><hr>
			<div class="row">
				<table class="table table-striped" id="myTable">				  				  
				 <tbody>
				  	<?php for($nLinhas = 0; $nLinhas < $linhas; $nLinhas++): ?>
				  		<tr>
				  			<?php for($nColunas = 0; $nColunas < $colunas; $nColunas++): ?>
				  				<td> <?="Linha: $nLinhas | Coluna: $nColunas";?> </td>
				  			<?php endfor; ?>
				  		</tr>
				  	<?php endfor; ?>	
				  </tbody>
				</table>
			</div>
		</div>			    
		<div class="col-1"></div>			    
	  </div>
	</div>

	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Exclusão de Registro</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	        Tem certeza que deseja excluir?
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Não</button>
	        <button type="button" class="btn btn-primary">Sim</button>
	      </div>
	    </div>
	  </div>
	</div>


	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js"></script>
	<script src="https://code.iconify.design/2/2.2.1/iconify.min.js"></script>
	<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

	<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>


	<script type="text/javascript">
		$(document).ready(function() {
		    $('#myTable').DataTable( {
		        dom: 'Bfrtip',
		        buttons: [
		            'copy', 'csv', 'excel', 'pdf', 'print'
		        ]
		    } );
		} )
	</script>
</body>
</html>


