<?php
	
	# Analisar o mês do ano (corrente) através do Numero dele

	/*if($mes == 1){
		echo "Janeiro";
	}elseif ($mes == 2) {
		echo "Fevereiro";
	}*/
	$mes = 15;

	switch ($mes) {
		case 1:
			echo "Janeiro";
		break;

		case 2:
			echo "Fevereiro";
		break;

		case 3:
			echo "Março";
		break;

		default:
			echo "Nao é um mês válido (se $mes < 13 e $mes > 0)!";

	}