<?php  
	
	# Laços de Repetição
	
	
	/*
	# Problema: contar de 0 a 100
	# PARA DE x ATE Y 
	# inicio; condição (fim); incremento 
	for($w = 0;$w < 11; $w++){
		echo "Contando... ".$w.'<br>';
	}

	# Problema: Contador 2022 até 1900
	for($t = 2022;$t > 1899; $t--){
		echo "Contando... ".$t.'<br>';
	}
	*/

	for($a=0,$b=10,$c=100; $b < 101; $a++, $b+=10, $c+=100){
		echo "Enquanto A é $a,  B é $b e o C é $c <br>";
	}

?>

<!-- <select>
	<?php for($ano = 2022; $ano > 1899; $ano--): ?>
		<option><?=$ano;?></option>
	<?php endfor; ?>
</select> -->