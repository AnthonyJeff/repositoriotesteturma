<?php
	
	/*
	# Randomizando uma idade 
	$idade = 16;
	echo "Sua idade {$idade} <br>";



	# SE minha idade for maior 17 anos, então eu sou maior de idade
	# SENAO eu nao sou maior de idade e nem posso dirigir (e nem ser preso)
	
	# Maior que 17 [ e maior que 15 ] - maior de idade e pode votar	
	# Menor que 18 [ e maior que 15 ] - menor de idade e tbm pode votar
	# Menor que 15 - menor de idade e nao pode votar

	if($idade > 17){
		echo "Maior e pode votar! <br>";
	}else{
		if($idade > 15){
			echo "Menor mas pode votar! <br>";
		}else{
			echo "Menor e nao pode votar!";
		}
	}

	if($idade > 17){
		echo "Maior e pode votar <br>";
	}elseif($idade > 15){
		echo "Menor mas pode votar! <br>";
	}else{
		echo "Menor e nao pode votar!";
	}	
	*/

	$nome = "Anthony"; //String
	$idade = 18; // Inteiro 
	$saldoBancario = 865.23; // Float ou Double
	$sexo = true; // Boleano 

	# Operador Ternário
	echo (!$sexo) ? "Bem vinda Sra. ".$nome."<br>" : "Bem vindo Sr. ".$nome."<br>";
	


	/*if(!$sexo){
		echo "Bem vinda Sra. ",$nome,"<br>";		
	}else{
		echo "Bem vindo Sr. ",$nome,"<br>";
	}
	*/
	echo "Tenho ".$idade." anos <br>";
	
	if($saldoBancario < 0){
		echo "Seu saldo está negativo em R$ {$saldoBancario} <br>";
	}else{
		echo "Seu saldo é R$ {$saldoBancario} <br>";		
	}	


?>