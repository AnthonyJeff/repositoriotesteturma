<form action="#" method="POST">
	<input type="number" name="l1" placeholder="N1"><br>		
	<input type="number" name="l2" placeholder="N2"><br>		
	<input type="number" name="l3" placeholder="N2"><br>		
	<input type="submit" name="submit" value="VERIFICAR">
</form>

<?php 
	
	if(isset($_POST['submit'])){
		
		if(
			$_POST['l1']+$_POST['l2'] > $_POST['l3'] &&
			$_POST['l1']+$_POST['l3'] > $_POST['l2'] &&
			$_POST['l2']+$_POST['l3'] > $_POST['l1']
		){
			echo "Os lados formam um triangulo <br>";

			if($_POST['l1'] == $_POST['l2'] && $_POST['l2'] == $_POST['l3']){
				echo "O Triangulo é EQUILATERO";
			}elseif($_POST['l1'] == $_POST['l2'] || $_POST['l1'] == $_POST['l3'] || $_POST['l2'] == $_POST['l3']){
				echo "O Triangulo é ISOCELES";
			}else{
				echo "O Triangulo é ESCALENO";
			}	


		}else{
			echo "Esse não é um triangulo válido";
		}
	}
?>