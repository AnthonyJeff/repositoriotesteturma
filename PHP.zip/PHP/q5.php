<form action="#" method="POST">
	<input type="email" name="email" placeholder="email"><br>		
	<input type="password" name="senha" placeholder="senha"><br>				
	<input type="submit" name="submit" value="VERIFICAR">
</form>

<?php 
	
	if(isset($_POST['submit'])){
		
		if($_POST['email'] != "admin@admin.com"){
			echo "Usuário não encontrado!!!";
		}elseif($_POST['senha'] != "123456"){
			echo "Senha incorreta";
		}else{
			echo "Bem vindo ao sistema!!!!";
		}		

	}
?>