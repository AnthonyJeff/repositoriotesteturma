<!DOCTYPE html>
<html>
<head>
	<title> Formulario </title>
</head>
<body>
	<form>
		<label> Nome Completo </label><br>
		<input type="text"><br><br>

		<label> Email </label><br>
		<input type="email"><br><br>

		<label> Data de Nascimento </label><br>
		<input type="date"><br><br>

		<label> Senha </label><br>
		<input type="password"><br><br>

		<input type="submit" value="Enviar Dados">
	</form>


</body>
</html>