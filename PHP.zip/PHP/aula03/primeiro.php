<?php


	$nome = "Anthony"; //String
	$idade = 18; // Inteiro 
	$saldoBancario = -865.23; // Float ou Double
	$sexo = false; // Boleano 

	echo "Meu nome é ".$nome."<br>";
	//echo "Tenho ".$idade."anos <br>";
	


?>