<?php  

	$nome = 'Anthony';
	$email = 'anthony@emial';
	$dtnasc = '01/12/1999';
	$senha = '123456';
	$cpf = '12132456456';
	$telefone = '(85) 99999-0000';


	$cadastro = array(
		"nome" => $nome,
		"email" => $email,
		"dtnasc" => $dtnasc,
		"senha" => $senha,
		"cpf" => $cpf,
		"telefone" => $telefone
	);

	echo "Nome: ".$cadastro['nome']."<br>";
?>