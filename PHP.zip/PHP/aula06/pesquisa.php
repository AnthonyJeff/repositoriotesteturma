<!DOCTYPE html>
<html>
<head>
	<title> Formulario </title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
</head>
<body>
	<div class="container-fluid">
	  <div class="row">
		<div class="col-2"></div>			    
		<div class="col-8">
			<h1 class="text-center"> Pesquisa </h1><hr>
			<form action="#" method="POST">
				<div class="row">
					<div class="mb-3 col-9">					  	
					  <input type="text" class="form-control input-lg" placeholder="Pesquise Agora" name="pesquisa">
					</div>

					<div class="mb-3 col-3">					  	
					  <select class="form-control" name="buscador">
					  	<option> Google </option>
					  	<option> Bing </option>
					  	<option> DuckDuckGo </option>
					  	<option> Yahoo </option>
					  </select>
					</div>

					<div class="mb-3 col-12 text-end">
						<button type="submit" class="btn btn-outline-primary">
						<span class="iconify" data-icon="fluent:search"></span>
							Pesquisar
						</button>
					</div>
				</form>
			</div>

		</div>			    
		<div class="col-2"></div>			    
	  </div>
	</div>

	<?php  

		# Mostrar todo o conteudo do POST	
		if(isset($_POST['pesquisa'])){	
			$pesquisa = $_POST['pesquisa'];
			$buscador = $_POST['buscador'];

			switch ($buscador) {
				case 'Google':
					$url = "https://www.google.com/search?q=".$pesquisa;
					break;
				
				case 'Bing':
					$url = "https://www.bing.com/search?q=".$pesquisa;
					break;	

				case 'DuckDuckGo':
					$url = "https://duckduckgo.com/?q=".$pesquisa;
					break;
						
				case 'Yahoo':
					$url = "https://br.search.yahoo.com/search?p=".$pesquisa;
					break;			
			}

			if(!empty($url)){
				header("location: ".$url);
			}
		}
		
	?>	


	<script src="https://code.iconify.design/2/2.2.1/iconify.min.js"></script>
</body>
</html>