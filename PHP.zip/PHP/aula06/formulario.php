<!DOCTYPE html>
<html>
<head>
	<title> Formulario </title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
</head>
<body>
	<div class="container-fluid">
	  <div class="row">
		<div class="col-2"></div>			    
		<div class="col-8">
			<h1 class="text-center"> Formulário </h1><hr>
			<form action="recebe.php" method="POST">
				<div class="row">
					<div class="mb-3 col-7">
					  	<label for="nome-completo" class="form-label">
					  		<span class="iconify" data-icon="fa:address-card"></span> Nome Completo
						</label>
					  <input type="text" class="form-control" id="nome-completo" placeholder="Digite seu nome" name="nome">
					</div>

					<div class="mb-3 col-5">
					  <label for="dtnasc" class="form-label">
					  	<span class="iconify" data-icon="fa:birthday-cake"></span>
					  		Data de Nasc.
					  	</label>
					  <input type="date" class="form-control" name="dtnasc" id="dtnasc" placeholder="Digite seu nome">
					</div>

					<div class="mb-3 col-6">
					  <label for="email" class="form-label">
					  	<span class="iconify" data-icon="clarity:email-solid"></span> Email
					  </label>
					  <input type="email" class="form-control" name="email" id="email" placeholder="Digite seu email">
					</div>

					<div class="mb-3 col-6">
					  <label for="senha" class="form-label">
					  	<span class="iconify" data-icon="fa6-solid:key" style="color: gold;"></span> Senha
					  </label>
					  <input type="password" class="form-control" name="senha" id="senha" placeholder="Digite sua senha">
					</div>

					<div class="mb-3 col-6">
					  <label for="CPF" class="form-label">
					  	<span class="iconify" data-icon="fa:address-card"></span> CPF
					  </label>
					  <input type="text" class="form-control" name="cpf" id="CPF" placeholder="Digite seu CPF">
					</div>

					<div class="mb-3 col-6">
					  <label for="telefone" class="form-label">
					  	<span class="iconify" data-icon="fa6-solid:phone" style="color: green;"></span> Telefone
					  </label>
					  <input type="text" class="form-control" name="telefone" id="telefone" placeholder="Digite sua telefone">
					</div>

					<div class="mb-3 col-6">
					  <label for="RG" class="form-label">
					  	<span class="iconify" data-icon="fa6-solid:phone" style="color: green;"></span> RG
					  </label>
					  <input type="text" class="form-control" name="rg" id="rg" placeholder="Digite sua RG">
					</div>

					<div class="mb-3 col-12 text-end">
						<button type="submit" class="btn btn-outline-primary">
						<span class="iconify" data-icon="fluent:send-20-filled"></span>
							Enviar Dados
						</button>
					</div>
				</form>
			</div>

		</div>			    
		<div class="col-2"></div>			    
	  </div>
	</div>

	<!--
	<form>
		<label> Nome Completo </label><br>
		<input type="text" required placeholder="Digite seu nome"><br><br>

		<label> Email </label><br>
		<input type="email" required placeholder="Digite seu email"><br><br>

		<label> Data de Nascimento </label><br>
		<input type="date" required><br><br>

		<label> Senha </label><br>
		<input type="password" required placeholder="Digite sua Senha"><br><br>

		<input type="submit" value="Enviar Dados">
	</form>
	-->
	<script src="https://code.iconify.design/2/2.2.1/iconify.min.js"></script>
</body>
</html>