<?php  

	# Recebendo os dados do Formulário
	/*$cadastro = array(
		"nome" => $_POST['nome'],
		"email" => $_POST['email'],
		"dtnasc" => $_POST['dtnasc'],
		"senha" => $_POST['senha'],
		"cpf" => $_POST['cpf'],
		"telefone" => $_POST['telefone']
	);*/

	foreach($_POST as $key=>$cadaDado){
		echo $key." - ".$cadaDado."<br>";
	}
?>