<?php  

	# função que soma 2+2
	function soma2com2(){
		echo 2 + 2;
		echo "<br>";
	}

	# Soma com parametros
	function soma($x, $y){
		echo $x + $y;
		echo "<br>";
	}

	# Chamada da função
	$x = 3;
	$y = 5;

	soma($x, $y);
	soma(100, 200);
	echo "<hr>";


	$nome = "anthony";

	function mostrarNome(){
		global $nome;
		echo $nome;
	}

	$nome = "Jhonathan";
	mostrarNome();


	echo "<hr>";

	# Calcula o IMC de uma pessoa
	function imc($peso, $altura){
		$imc = ($peso)/pow($altura, 2);
		return $imc;
	}

	$imcAserTestado = imc(111, 1.85);

	if($imcAserTestado < 18.5){
		echo "Abaixo do Peso";
	}elseif($imcAserTestado < 25){
		echo "Peso Normal";
	}elseif($imcAserTestado < 30){
		echo "Sobrepeso";
	}elseif($imcAserTestado < 35){
		echo "OBS 1";
	}elseif($imcAserTestado < 40){
		echo "OBS 2";
	}else{
		echo "OBS 3 ou OBS Mórbida";
	}
	echo "<br>";
	echo "Chave MD5 do seu IMC: ".md5($imcAserTestado);
?>