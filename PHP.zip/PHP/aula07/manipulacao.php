<?php  
	
	# Criar ou abrir um arquivo
	$arquivo = fopen("teste.txt", "a+");

	# Escrevendo no arquivo
	fwrite($arquivo, "Batatinha Frita, 123...\n");

	# Fechando a manipulação
	fclose($arquivo);


?>