<?php  

	
	echo str_repeat("Carro pancadão, Hey!!! <br>", 5);
	echo md5("String")."<br>";
	echo sha1("String")."<br>";
	echo str_replace("-", "/", "19-01-1990");
	echo "<hr>";

	# Trasformando um array em string
	$cadastro['nome'] = "Anthony";
	$cadastro['email'] = "anthony@email.com";
	$cadastro['cpf'] = "12345678900";

	$string = implode(" - ", $cadastro);

	echo $string;
	echo "<hr>";

	# Transformar uma string em um array
	$dados = explode(" - ", $string);
	echo "<pre>"; 
	echo print_r($dados);
	echo "</pre>";






?>		