<?php  
	
	# Criar ou abrir um arquivo
	$arquivo = fopen("patinhos.txt", "a+");


	for($pato=5;$pato>=1;$pato--){
		# Escrevendo no arquivo
		fwrite($arquivo, "$pato patinhos foram passear...\n");
		fwrite($arquivo, "Além das montanhas para brincar...\n");
		fwrite($arquivo, "A mamae gritou QUA QUA QUA QUA...\n");
		if($pato == 1){
			fwrite($arquivo, "Mas nenhum patinho voltou de lá...\n");
		}else{
			fwrite($arquivo, "Mas só ".($pato-1)." voltaram de lá...\n");
		}

		fwrite($arquivo, "\n");
	}
	
	# Fechando a manipulação
	fclose($arquivo);

?>